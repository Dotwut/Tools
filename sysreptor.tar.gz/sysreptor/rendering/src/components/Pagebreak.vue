<template>
    <div class="pagebreak" />
</template>

<style scoped>
.pagebreak {
    break-after: always;
    display: block;
}
</style>