<template>
  <div />
</template>

<script>
export default {
  fetch() {
    this.$router.push('/projects/');
  }
}
</script>
